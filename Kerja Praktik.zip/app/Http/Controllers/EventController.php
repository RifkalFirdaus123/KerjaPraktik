<?php

namespace App\Http\Controllers;

use App\Models\Event;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class EventController extends Controller
{
    public function __construct()
    {
        // Hanya biarkan halaman index yang bisa diakses tanpa login
        $this->middleware('auth')->except(['index']);
    }

    // Menampilkan daftar event
    public function index()
    {
        $events = Event::latest()->get(); // Mengambil data event terbaru
        return view('events.index', compact('events'));
    }

    // Menampilkan form untuk membuat event baru
    public function create()
    {
        return view('events.create');
    }

    // Menyimpan event baru ke database
    public function store(Request $request)
    {
        $validated = $request->validate([
            'nama_event' => 'required|string|max:255',
            'deskripsi'  => 'required|string',
            'foto'       => 'nullable|image|max:2048', // Foto harus gambar dan maksimal 2MB
            'tanggal'    => 'nullable|date', // Pastikan format tanggal benar
            'waktu'      => 'required',
        ]);

        // Menyimpan foto jika ada
        if ($request->hasFile('foto')) {
            $validated['foto'] = $request->file('foto')->store('foto_event', 'public');
        }

        // Menyimpan event ke database
        Event::create($validated);

        return redirect()->route('events.index')
                         ->with('success', 'Event berhasil ditambahkan.');
    }

    // Menampilkan form untuk mengedit event
    public function edit(Event $event)
    {
        return view('events.edit', compact('event'));
    }

    // Memperbarui data event
    public function update(Request $request, Event $event)
    {
        $validated = $request->validate([
            'nama_event' => 'required|string|max:255',
            'deskripsi'  => 'required|string',
            'foto'       => 'nullable|image|max:2048',
            'tanggal'    => 'nullable|date',
            'waktu'      => 'required',
        ]);

        // Jika ada foto baru yang diupload
        if ($request->hasFile('foto')) {
            // Menghapus foto lama jika ada
            if ($event->foto) {
                Storage::disk('public')->delete($event->foto);
            }
            // Menyimpan foto baru
            $validated['foto'] = $request->file('foto')->store('foto_event', 'public');
        }

        // Memperbarui data event
        $event->update($validated);

        return redirect()->route('events.index')
                         ->with('success', 'Event berhasil diperbarui.');
    }

    // Menghapus event
    public function destroy(Event $event)
    {
        // Menghapus foto terkait jika ada
        if ($event->foto) {
            Storage::disk('public')->delete($event->foto);
        }

        // Menghapus event dari database
        $event->delete();

        return redirect()->route('events.index')
                         ->with('success', 'Event berhasil dihapus.');
    }
}
