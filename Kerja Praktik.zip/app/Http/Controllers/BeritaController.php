<?php

namespace App\Http\Controllers;

use App\Models\Berita;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class BeritaController extends Controller
{
    public function __construct()
    {
        // Hanya biarkan halaman index yang bisa diakses tanpa login
        $this->middleware('auth')->except(['index']);
    }

    // Menampilkan daftar berita
    public function index()
    {
        $beritas = Berita::latest()->get(); // Mengambil data berita terbaru
        return view('beritas.index', compact('beritas'));
    }

    // Menampilkan form untuk membuat berita baru
    public function create()
    {
        return view('beritas.create');
    }

    // Menyimpan berita baru ke database
    public function store(Request $request)
    {
        $validated = $request->validate([
            'judul'     => 'required|string|max:255',
            'konten'    => 'required|string',
            'foto'      => 'nullable|image|max:2048', // Foto harus gambar dan maksimal 2MB
            'tanggal'   => 'nullable|date', // Pastikan format tanggal benar
        ]);

        // Menyimpan foto jika ada
        if ($request->hasFile('foto')) {
            $validated['foto'] = $request->file('foto')->store('foto_berita', 'public');
        }

        // Menyimpan berita ke database
        Berita::create($validated);

        return redirect()->route('beritas.index')
                         ->with('success', 'Berita berhasil ditambahkan.');
    }

    // Menampilkan form untuk mengedit berita
    public function edit(Berita $berita)
    {
        return view('beritas.edit', compact('berita'));
    }

    // Memperbarui data berita
    public function update(Request $request, Berita $berita)
    {
        $validated = $request->validate([
            'judul'     => 'required|string|max:255',
            'konten'    => 'required|string',
            'foto'      => 'nullable|image|max:2048',
            'tanggal'   => 'nullable|date',
        ]);

        // Jika ada foto baru yang diupload
        if ($request->hasFile('foto')) {
            // Menghapus foto lama jika ada
            if ($berita->foto) {
                Storage::disk('public')->delete($berita->foto);
            }
            // Menyimpan foto baru
            $validated['foto'] = $request->file('foto')->store('foto_berita', 'public');
        }

        // Memperbarui data berita
        $berita->update($validated);

        return redirect()->route('beritas.index')
                         ->with('success', 'Berita berhasil diperbarui.');
    }

    // Menghapus berita
    public function destroy(Berita $berita)
    {
        // Menghapus foto terkait jika ada
        if ($berita->foto) {
            Storage::disk('public')->delete($berita->foto);
        }

        // Menghapus berita dari database
        $berita->delete();

        return redirect()->route('beritas.index')
                         ->with('success', 'Berita berhasil dihapus.');
    }
}
