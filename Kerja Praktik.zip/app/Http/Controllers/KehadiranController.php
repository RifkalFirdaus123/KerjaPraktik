<?php

namespace App\Http\Controllers;

use App\Models\Kehadiran;
use App\Models\Event;
use Illuminate\Http\Request;

class KehadiranController extends Controller
{
    public function index()
    {
        $kehadirans = Kehadiran::all();
        return view('kehadirans.index', compact('kehadirans'));
    }

    public function create()
    {
        $events = Event::all();  // mengambil daftar event
        return view('kehadirans.create', compact('events'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'event_id' => 'required|exists:events,id',
            'nama' => 'required|string',
            'nim' => 'required|string',
            'kontak' => 'required|string',
        ]);

        Kehadiran::create($request->all());

        return redirect()->route('kehadirans.index')->with('success', 'Kehadiran berhasil dicatat!');
    }

    public function edit(Kehadiran $kehadiran)
    {
        $events = Event::all();
        return view('kehadirans.edit', compact('kehadiran', 'events'));
    }

    public function update(Request $request, Kehadiran $kehadiran)
    {
        $request->validate([
            'event_id' => 'required|exists:events,id',
            'nama' => 'required|string',
            'nim' => 'required|string',
            'kontak' => 'required|string',
        ]);

        $kehadiran->update($request->all());

        return redirect()->route('kehadirans.index')->with('success', 'Kehadiran berhasil diperbarui!');
    }

    public function destroy(Kehadiran $kehadiran)
    {
        $kehadiran->delete();
        return redirect()->route('kehadirans.index')->with('success', 'Kehadiran berhasil dihapus!');
    }
}
