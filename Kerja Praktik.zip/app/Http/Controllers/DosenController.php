<?php
namespace App\Http\Controllers;

use App\Models\Dosen;
use Illuminate\Http\Request;

class DosenController extends Controller
{
    public function __construct()
    {
        // Semua method kecuali index (dan show jika ada) butuh login
        $this->middleware('auth')->except(['index']);
    }

    public function index()
    {
        $dosens = Dosen::latest()->get();
        return view('dosens.index', compact('dosens'));
    }

    // create, store, edit, update, destroy otomatis ter‑middleware auth
}
