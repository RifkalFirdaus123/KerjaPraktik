<?php

namespace App\Http\Controllers;

use App\Models\PeminjamanBarang;
use Illuminate\Http\Request;

class PermintaanController extends Controller
{
    public function index()
    {
        // Ambil semua data peminjaman barang
        $peminjamanBarangs = PeminjamanBarang::all();

        // Tampilkan data dalam view
        return view('permintaans.index', compact('peminjamanBarangs'));
    }
}
