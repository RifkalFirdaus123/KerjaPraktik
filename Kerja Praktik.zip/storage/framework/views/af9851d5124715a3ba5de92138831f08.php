

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Daftar Permintaan Peminjaman Barang</h2>
    <table class="table">
        <thead>
            <tr>
                <th>#</th>
                <th>Nama Peminjam</th>
                <th>NIM/NIP</th>
                <th>Nama Barang</th>
                <th>Jumlah</th>
                <th>Tanggal Peminjaman</th>
                <th>Tanggal Pengembalian</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $peminjamanBarangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peminjaman): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($peminjaman->nama_peminjam); ?></td>
                <td><?php echo e($peminjaman->nim_nip); ?></td>
                <td><?php echo e($peminjaman->nama_barang); ?></td>
                <td><?php echo e($peminjaman->jumlah); ?></td>
                <td><?php echo e($peminjaman->tanggal_peminjaman); ?></td>
                <td><?php echo e($peminjaman->tanggal_pengembalian); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\KerjaPraktik\resources\views/permintaans/index.blade.php ENDPATH**/ ?>