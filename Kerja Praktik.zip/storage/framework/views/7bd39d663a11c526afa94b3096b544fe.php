

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Daftar Kehadiran</h1>
        <a href="<?php echo e(route('kehadirans.create')); ?>" class="btn btn-primary mb-3">Tambah Kehadiran</a>
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Event</th>
                    <th>Nama</th>
                    <th>NIM</th>
                    <th>Kontak</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $kehadirans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kehadiran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($kehadiran->event->judul); ?></td>
                        <td><?php echo e($kehadiran->nama); ?></td>
                        <td><?php echo e($kehadiran->nim); ?></td>
                        <td><?php echo e($kehadiran->kontak); ?></td>
                        <td>
                            <a href="<?php echo e(route('kehadirans.edit', $kehadiran)); ?>" class="btn btn-warning">Edit</a>
                            <form action="<?php echo e(route('kehadirans.destroy', $kehadiran)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\KerjaPraktik\resources\views/kehadirans/index.blade.php ENDPATH**/ ?>