<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Aplikasi Laravel</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
  <div class="container">
    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">LaravelApp</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNav">
      <!-- Menu navigasi selalu tampil -->
      <ul class="navbar-nav me-auto">
      <li class="nav-item"><a class="nav-link" href="<?php echo e(route('dosens.index')); ?>">Dosen</a></li> 
        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('beritas.index')); ?>">Berita</a></li>
        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('events.index')); ?>">Event</a></li>
        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('peminjaman-barangs.index')); ?>">Peminjaman Barang</a></li>
        
        <!-- Hanya muncul jika sudah login -->
        <?php if(auth()->guard()->check()): ?>
          <li class="nav-item"><a class="nav-link" href="<?php echo e(route('kehadirans.index')); ?>">Kehadiran</a></li>
          <li class="nav-item"><a class="nav-link" href="<?php echo e(route('permintaans.index')); ?>">Permintaan</a></li>
        <?php endif; ?>
      </ul>

      <!-- Login / Logout -->
      <ul class="navbar-nav ms-auto">
        <?php if(auth()->guard()->check()): ?>
          <li class="nav-item">
            <form method="POST" action="<?php echo e(route('logout')); ?>">
              <?php echo csrf_field(); ?>
              <button class="btn btn-link nav-link" type="submit">Logout</button>
            </form>
          </li>
        <?php else: ?>
          <li class="nav-item"><a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a></li>
          <li class="nav-item"><a class="nav-link" href="<?php echo e(route('register')); ?>">Register</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>


  <!-- Main Content -->
  <main class="container">
    <?php echo $__env->yieldContent('content'); ?>
  </main>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\Users\USER\KerjaPraktik\resources\views/layouts/app.blade.php ENDPATH**/ ?>