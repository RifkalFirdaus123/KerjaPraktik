

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Daftar Berita</h1>
    <?php if(auth()->guard()->check()): ?>
    <a href="<?php echo e(route('beritas.create')); ?>" class="btn btn-primary mb-3">Tambah Berita</a>
    <?php endif; ?>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Judul</th>
                <th>Tanggal</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $beritas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($berita->judul); ?></td>
                    <td><?php echo e($berita->tanggal ?? '-'); ?></td>
                    <td>
                        <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(route('beritas.edit', $berita)); ?>" class="btn btn-sm btn-warning">Edit</a>
                        <form action="<?php echo e(route('beritas.destroy', $berita)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button onclick="return confirm('Yakin ingin menghapus berita ini?')" class="btn btn-sm btn-danger">Hapus</button>
                        </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\KerjaPraktik\resources\views/beritas/index.blade.php ENDPATH**/ ?>