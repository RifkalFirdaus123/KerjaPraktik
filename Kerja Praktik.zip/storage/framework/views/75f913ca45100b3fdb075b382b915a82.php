

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Data Dosen</h1>

    
    <?php if(auth()->guard()->check()): ?>
    <a href="<?php echo e(route('dosens.create')); ?>" class="btn btn-primary mb-3">Tambah Dosen</a>
    <?php endif; ?>

    <table class="table table-bordered">
        <thead>…</thead>
        <tbody>
            <?php $__currentLoopData = $dosens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($dosen->nama); ?></td>
                <td><?php echo e($dosen->nip); ?></td>
                <td><?php echo e($dosen->prodi); ?></td>
                <td>
                    
                    <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('dosens.edit', $dosen)); ?>" class="btn btn-sm btn-warning">Edit</a>
                    <form action="<?php echo e(route('dosens.destroy', $dosen)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-danger" onclick="return confirm('Yakin?')">Hapus</button>
                    </form>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\KerjaPraktik\resources\views/dosens/index.blade.php ENDPATH**/ ?>