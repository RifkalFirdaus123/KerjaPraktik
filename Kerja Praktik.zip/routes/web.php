<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\BeritaController;
use App\Http\Controllers\DosenController;
use App\Http\Controllers\EventController;
use App\Http\Controllers\KehadiranController;
use App\Http\Controllers\PeminjamanBarangController;
use App\Http\Controllers\PermintaanController;

Route::get('/', [DosenController::class, 'index']);

// Dashboard Route
Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

// Profile Routes
Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

// Resource Routes for CRUD operations
Route::resource('beritas', BeritaController::class);
Route::resource('dosens', DosenController::class);
Route::resource('events', EventController::class);
Route::resource('kehadirans', KehadiranController::class);
Route::resource('peminjaman-barangs', PeminjamanBarangController::class);
Route::resource('permintaans', PermintaanController::class);

// Authentication Routes
require __DIR__.'/auth.php';
