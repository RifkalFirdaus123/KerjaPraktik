public function up()
{
    Schema::create('barangs', function (Blueprint $table) {
        $table->id();
        $table->string('nama_barang');
        $table->integer('stok');
        $table->timestamps();
    });
}
