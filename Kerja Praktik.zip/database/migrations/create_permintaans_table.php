<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up()
    {
        Schema::create('permintaans', function (Blueprint $table) {
            $table->id();
            $table->string('nama_peminjam');
            $table->string('nim_nip', 50);
            $table->string('nama_barang');
            $table->string('kategori_barang')->nullable();
            $table->integer('jumlah');
            $table->date('tanggal_peminjaman');
            $table->date('tanggal_pengembalian');
            $table->enum('status', ['Menunggu Persetujuan','Disetujui','Ditolak'])
                  ->default('Menunggu Persetujuan');
            $table->timestamp('tanggal_pengajuan')->useCurrent();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('permintaans');
    }
};