<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Event;

class EventSeeder extends Seeder
{
    public function run()
    {
        Event::create([
            'nama_event' => 'Seminar Teknologi',
            'deskripsi' => 'Seminar mengenai perkembangan teknologi terbaru.',
            'foto' => null,
            'tanggal' => '2025-05-15',
            'waktu' => '09:00',
        ]);

        Event::create([
            'nama_event' => 'Workshop Laravel',
            'deskripsi' => 'Workshop tentang pengembangan aplikasi menggunakan Laravel.',
            'foto' => null,
            'tanggal' => '2025-05-20',
            'waktu' => '13:00',
        ]);
    }
}
