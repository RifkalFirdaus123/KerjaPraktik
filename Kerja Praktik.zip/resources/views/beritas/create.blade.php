@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Tambah Berita</h1>

    <form action="{{ route('beritas.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="mb-3">
            <label>Judul</label>
            <input type="text" name="judul" class="form-control" value="{{ old('judul') }}">
            @error('judul') <small class="text-danger">{{ $message }}</small> @enderror
        </div>
        <div class="mb-3">
            <label>Isi</label>
            <textarea name="isi" class="form-control">{{ old('isi') }}</textarea>
            @error('isi') <small class="text-danger">{{ $message }}</small> @enderror
        </div>
        <div class="mb-3">
            <label>Foto (Opsional)</label>
            <input type="file" name="foto" class="form-control">
            @error('foto') <small class="text-danger">{{ $message }}</small> @enderror
        </div>
        <button class="btn btn-success">Simpan</button>
        <a href="{{ route('beritas.index') }}" class="btn btn-secondary">Kembali</a>
    </form>
</div>
@endsection
