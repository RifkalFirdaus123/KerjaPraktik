@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Edit Berita</h1>

    <form action="{{ route('beritas.update', $berita) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')
        <div class="mb-3">
            <label>Judul</label>
            <input type="text" name="judul" class="form-control" value="{{ old('judul', $berita->judul) }}">
            @error('judul') <small class="text-danger">{{ $message }}</small> @enderror
        </div>
        <div class="mb-3">
            <label>Isi</label>
            <textarea name="isi" class="form-control">{{ old('isi', $berita->isi) }}</textarea>
            @error('isi') <small class="text-danger">{{ $message }}</small> @enderror
        </div>
        <div class="mb-3">
            <label>Foto Saat Ini</label><br>
            @if ($berita->foto)
                <img src="{{ asset('storage/' . $berita->foto) }}" width="100"><br>
            @else
                Tidak ada foto
            @endif
        </div>
        <div class="mb-3">
            <label>Ganti Foto</label>
            <input type="file" name="foto" class="form-control">
            @error('foto') <small class="text-danger">{{ $message }}</small> @enderror
        </div>
        <button class="btn btn-primary">Update</button>
        <a href="{{ route('beritas.index') }}" class="btn btn-secondary">Kembali</a>
    </form>
</div>
@endsection
