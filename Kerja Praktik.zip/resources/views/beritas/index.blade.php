@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Daftar Berita</h1>
    @auth
    <a href="{{ route('beritas.create') }}" class="btn btn-primary mb-3">Tambah Berita</a>
    @endauth

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Judul</th>
                <th>Tanggal</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            @foreach($beritas as $berita)
                <tr>
                    <td>{{ $berita->judul }}</td>
                    <td>{{ $berita->tanggal ?? '-' }}</td>
                    <td>
                        @auth
                        <a href="{{ route('beritas.edit', $berita) }}" class="btn btn-sm btn-warning">Edit</a>
                        <form action="{{ route('beritas.destroy', $berita) }}" method="POST" class="d-inline">
                            @csrf
                            @method('DELETE')
                            <button onclick="return confirm('Yakin ingin menghapus berita ini?')" class="btn btn-sm btn-danger">Hapus</button>
                        </form>
                        @endauth
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
