@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Edit Kehadiran</h1>

        <form action="{{ route('kehadirans.update', $kehadiran) }}" method="POST">
            @csrf
            @method('PATCH')

            <div class="mb-3">
                <label for="event_id" class="form-label">Event</label>
                <select name="event_id" id="event_id" class="form-control" required>
                    @foreach ($events as $event)
                        <option value="{{ $event->id }}" {{ $kehadiran->event_id == $event->id ? 'selected' : '' }}>
                            {{ $event->judul }}
                        </option>
                    @endforeach
                </select>
            </div>

            <div class="mb-3">
                <label for="nama" class="form-label">Nama</label>
                <input type="text" name="nama" id="nama" class="form-control" value="{{ $kehadiran->nama }}" required>
            </div>

            <div class="mb-3">
                <label for="nim" class="form-label">NIM</label>
                <input type="text" name="nim" id="nim" class="form-control" value="{{ $kehadiran->nim }}" required>
            </div>

            <div class="mb-3">
                <label for="kontak" class="form-label">Kontak</label>
                <input type="text" name="kontak" id="kontak" class="form-control" value="{{ $kehadiran->kontak }}" required>
            </div>

            <button type="submit" class="btn btn-primary">Perbarui Kehadiran</button>
        </form>
    </div>
@endsection
