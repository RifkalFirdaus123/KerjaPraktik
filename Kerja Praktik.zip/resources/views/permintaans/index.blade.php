@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Daftar Permintaan Peminjaman Barang</h2>
    <table class="table">
        <thead>
            <tr>
                <th>#</th>
                <th>Nama Peminjam</th>
                <th>NIM/NIP</th>
                <th>Nama Barang</th>
                <th>Jumlah</th>
                <th>Tanggal Peminjaman</th>
                <th>Tanggal Pengembalian</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($peminjamanBarangs as $peminjaman)
            <tr>
                <td>{{ $loop->iteration }}</td>
                <td>{{ $peminjaman->nama_peminjam }}</td>
                <td>{{ $peminjaman->nim_nip }}</td>
                <td>{{ $peminjaman->nama_barang }}</td>
                <td>{{ $peminjaman->jumlah }}</td>
                <td>{{ $peminjaman->tanggal_peminjaman }}</td>
                <td>{{ $peminjaman->tanggal_pengembalian }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
