@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Edit Event</h1>

        <form action="{{ route('events.update', $event->id) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="form-group">
                <label for="nama_event">Nama Event</label>
                <input type="text" name="nama_event" id="nama_event" class="form-control" value="{{ $event->nama_event }}" required>
            </div>

            <div class="form-group">
                <label for="deskripsi">Deskripsi</label>
                <textarea name="deskripsi" id="deskripsi" class="form-control" rows="4" required>{{ $event->deskripsi }}</textarea>
            </div>

            <div class="form-group">
                <label for="tanggal">Tanggal</label>
                <input type="date" name="tanggal" id="tanggal" class="form-control" value="{{ $event->tanggal }}" required>
            </div>

            <div class="form-group">
                <label for="waktu">Waktu</label>
                <input type="time" name="waktu" id="waktu" class="form-control" value="{{ $event->waktu }}" required>
            </div>

            <button type="submit" class="btn btn-warning mt-3">Perbarui</button>
        </form>
    </div>
@endsection
