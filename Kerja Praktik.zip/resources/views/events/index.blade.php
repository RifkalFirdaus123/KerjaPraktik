@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Daftar Event</h1>
    @auth
    <a href="{{ route('events.create') }}" class="btn btn-primary mb-3">Tambah Event</a>
    @endauth

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Nama Event</th>
                <th>Tanggal</th>
                <th>Waktu</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            @foreach($events as $event)
                <tr>
                    <td>{{ $event->nama_event }}</td>
                    <td>{{ $event->tanggal ?? '-' }}</td>
                    <td>{{ $event->waktu }}</td>
                    <td>
                        @auth
                        <a href="{{ route('events.edit', $event) }}" class="btn btn-sm btn-warning">Edit</a>
                        <form action="{{ route('events.destroy', $event) }}" method="POST" class="d-inline">
                            @csrf
                            @method('DELETE')
                            <button onclick="return confirm('Yakin ingin menghapus event ini?')" class="btn btn-sm btn-danger">Hapus</button>
                        </form>
                        @endauth
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
