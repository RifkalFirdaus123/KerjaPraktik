@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Data Dosen</h1>

    {{-- tombol tambah hanya untuk user login --}}
    @auth
    <a href="{{ route('dosens.create') }}" class="btn btn-primary mb-3">Tambah Dosen</a>
    @endauth

    <table class="table table-bordered">
        <thead>…</thead>
        <tbody>
            @foreach($dosens as $dosen)
            <tr>
                <td>{{ $dosen->nama }}</td>
                <td>{{ $dosen->nip }}</td>
                <td>{{ $dosen->prodi }}</td>
                <td>
                    {{-- tombol edit & hapus hanya untuk user login --}}
                    @auth
                    <a href="{{ route('dosens.edit', $dosen) }}" class="btn btn-sm btn-warning">Edit</a>
                    <form action="{{ route('dosens.destroy', $dosen) }}" method="POST" class="d-inline">
                        @csrf @method('DELETE')
                        <button class="btn btn-sm btn-danger" onclick="return confirm('Yakin?')">Hapus</button>
                    </form>
                    @endauth
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
