@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Tambah Dosen</h1>

    @if($errors->any())
      <div class="alert alert-danger">
        <ul>
        @foreach($errors->all() as $err)
          <li>{{ $err }}</li>
        @endforeach
        </ul>
      </div>
    @endif

    <form action="{{ route('dosens.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="mb-3">
            <label>Nama</label>
            <input type="text" name="nama" class="form-control" value="{{ old('nama') }}" required>
        </div>
        <div class="mb-3">
            <label>NIP</label>
            <input type="text" name="nip" class="form-control" value="{{ old('nip') }}" required>
        </div>
        <div class="mb-3">
            <label>Bidang</label>
            <input type="text" name="bidang" class="form-control" value="{{ old('bidang') }}">
        </div>
        <div class="mb-3">
            <label>Email</label>
            <input type="email" name="email" class="form-control" value="{{ old('email') }}" required>
        </div>
        <div class="mb-3">
            <label>Foto (opsional)</label>
            <input type="file" name="foto" class="form-control">
        </div>
        <button class="btn btn-success">Simpan</button>
        <a href="{{ route('dosens.index') }}" class="btn btn-secondary">Batal</a>
    </form>
</div>
@endsection
